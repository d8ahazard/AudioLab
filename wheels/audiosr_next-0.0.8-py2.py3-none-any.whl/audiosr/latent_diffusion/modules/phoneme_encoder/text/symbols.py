﻿""" from https://github.com/keithito/tacotron """

"""
Defines the set of symbols used in text input to the model.
"""
_pad = "_"
_punctuation = ';:,.!?Â¡Â¿â€”â€¦"Â«Â»â€œâ€ '
_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
_letters_ipa = "É‘ÉÉ’Ã¦É“Ê™Î²É”É•Ã§É—É–Ã°Ê¤É™É˜ÉšÉ›ÉœÉÉžÉŸÊ„É¡É É¢Ê›É¦É§Ä§É¥ÊœÉ¨ÉªÊÉ­É¬É«É®ÊŸÉ±É¯É°Å‹É³É²É´Ã¸ÉµÉ¸Î¸Å“É¶Ê˜É¹ÉºÉ¾É»Ê€ÊÉ½Ê‚ÊƒÊˆÊ§Ê‰ÊŠÊ‹â±±ÊŒÉ£É¤ÊÏ‡ÊŽÊÊ‘ÊÊ’Ê”Ê¡Ê•Ê¢Ç€ÇÇ‚ÇƒËˆËŒËË‘Ê¼Ê´Ê°Ê±Ê²Ê·Ë Ë¤Ëžâ†“â†‘â†’â†—â†˜'Ì©'áµ»"


# Export all symbols:
symbols = [_pad] + list(_punctuation) + list(_letters) + list(_letters_ipa)

# Special symbol ids
SPACE_ID = symbols.index(" ")

