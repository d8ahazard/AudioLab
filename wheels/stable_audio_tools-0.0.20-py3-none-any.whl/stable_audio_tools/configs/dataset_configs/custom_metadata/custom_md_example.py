def get_custom_metadata(info, audio):

    # Use relative path as the prompt
    return {"prompt": info["relpath"]}