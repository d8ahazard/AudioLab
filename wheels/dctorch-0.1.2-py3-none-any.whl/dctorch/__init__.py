from .functional import dct, idct, dct2, idct2, dct3, idct3

__all__ = ["dct", "idct", "dct2", "idct2", "dct3", "idct3"] 